package com.fourtech.eddata;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.fourtech.db.GpsDbHelper;
import com.fourtech.eddatatool.R;

public class Main extends Activity implements OnClickListener {
	private final String TAG = "todd";

	private Button mBtnRead, mBtnChange, mBtnSelect;
	private Button mBtnOrderStartLattitude;//排序(起点纬度,起点经度,终点纬度,终点经度)
	private GpsDbHelper mGpsDbHelper;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		mBtnRead = (Button) findViewById(R.id.btn_read);
		mBtnChange = (Button) findViewById(R.id.btn_change);
		mBtnSelect = (Button) findViewById(R.id.btn_select);
		mBtnRead.setOnClickListener(this);
		mBtnChange.setOnClickListener(this);
		mBtnSelect.setOnClickListener(this);
		
		mBtnOrderStartLattitude = (Button) findViewById(R.id.btn_order_by_start_lattitude);
//		mBtnOrderStartLongitude = (Button) findViewById(R.id.btn_order_by_start_longitude);
//		mBtnOrderEndLattitude = (Button) findViewById(R.id.btn_order_by_end_lattitude);
//		mBtnOrderEndLongitude = (Button) findViewById(R.id.btn_order_by_end_longitude);
		
		mBtnOrderStartLattitude.setOnClickListener(this);
//		mBtnOrderStartLongitude.setOnClickListener(this);
//		mBtnOrderEndLattitude.setOnClickListener(this);
//		mBtnOrderEndLongitude.setOnClickListener(this);
		
		
		
		mGpsDbHelper = new GpsDbHelper(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_read:
			mGpsDbHelper.loadData();
			break;
			
		case R.id.btn_change:
			mGpsDbHelper.ChangeByType();
			break;
			
		case R.id.btn_order_by_start_lattitude:
			mGpsDbHelper.order();
			break;
			
//		case R.id.btn_order_by_start_longitude:
//			//mGpsDbHelper.ChangeByType();
//			break;
//			
//		case R.id.btn_order_by_end_lattitude:
//			//mGpsDbHelper.ChangeByType();
//			break;
//			
//		case R.id.btn_order_by_end_longitude:
//			//mGpsDbHelper.ChangeByType();
//			break;
			
		case R.id.btn_select:
			mGpsDbHelper.query();
			break;
		default:
			break;
		}
	}

	



}
